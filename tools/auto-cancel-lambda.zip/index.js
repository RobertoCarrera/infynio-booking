const AWS = require('aws-sdk');

const region = process.env.AWS_REGION || 'eu-west-1';
const secretsManager = new AWS.SecretsManager({ region });

const SUPABASE_URL = process.env.SUPABASE_URL; // e.g. https://<project>.supabase.co
const SECRET_ARN = process.env.SUPABASE_SECRET_ARN; // ARN of the secret in Secrets Manager

exports.handler = async (event) => {
  console.log('auto-cancel Lambda invoked', { event });
  if (!SUPABASE_URL || !SECRET_ARN) {
    const msg = 'Missing SUPABASE_URL or SUPABASE_SECRET_ARN environment variables';
    console.error(msg);
    throw new Error(msg);
  }

  try {
    const secretResp = await secretsManager.getSecretValue({ SecretId: SECRET_ARN }).promise();
    const secretString = secretResp.SecretString || secretResp.SecretBinary && secretResp.SecretBinary.toString();
    if (!secretString) throw new Error('Empty secret value');

    const secret = JSON.parse(secretString);
    const svc = secret.service_role || secret.SERVICE_ROLE || secret.supabase_service_role;
    if (!svc) throw new Error('service_role key not found in secret');

    const res = await fetch(`${SUPABASE_URL.replace(/\/$/, '')}/rest/v1/rpc/auto_cancel_small_sessions`, {
      method: 'POST',
      headers: {
        'apikey': svc,
        'Authorization': `Bearer ${svc}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    });

    const text = await res.text();
    console.log('RPC response', { status: res.status, body: text });

    if (!res.ok) {
      const err = new Error(`RPC call failed with status ${res.status}: ${text}`);
      console.error(err);
      throw err;
    }

    return {
      statusCode: 200,
      body: text
    };
  } catch (err) {
    console.error('Handler error', err);
    // Let the error bubble so EventBridge / scheduler records a failure and retries according to its policy
    throw err;
  }
};
